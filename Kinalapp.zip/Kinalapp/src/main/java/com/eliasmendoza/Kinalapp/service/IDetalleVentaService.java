package com.eliasmendoza.Kinalapp.service;

import com.eliasmendoza.Kinalapp.entity.DetalleVenta;
import java.util.List;
import java.util.Optional;

public interface IDetalleVentaService {
    List<DetalleVenta> listarTodos();
    DetalleVenta guardar(DetalleVenta detalleVenta);
    Optional<DetalleVenta> buscarPorCodigo(int codigoDetalleVenta);
    DetalleVenta actualizar(int codigoDetalleVenta, DetalleVenta detalleVenta);
    void eliminar(int codigoDetalleVenta);
    boolean existePorCodigo(int codigoDetalleVenta);
}